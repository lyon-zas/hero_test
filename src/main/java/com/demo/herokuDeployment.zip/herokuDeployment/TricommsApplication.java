package com.demo.herokuDeployment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TricommsApplication {

	public static void main(String[] args) {

		SpringApplication.run(TricommsApplication.class, args);
	}

}
