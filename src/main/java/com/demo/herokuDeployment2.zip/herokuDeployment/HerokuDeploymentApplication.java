package com.demo.herokuDeployment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HerokuDeploymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HerokuDeploymentApplication.class, args);
	}

}
